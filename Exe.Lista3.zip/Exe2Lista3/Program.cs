﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe2Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            int x;
            int c;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite dois valores via teclado, respeitando a condição de 2º valor > 1º valor");
                Console.WriteLine("Digite o primeiro valor");
                n = int.Parse(Console.ReadLine());
                Console.WriteLine("Digite o segundo valor");
                x = int.Parse(Console.ReadLine());

            }
            while (n > x);
            Console.WriteLine("Parabéns, condição concluida!!");
        }
    }
}
