﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe6Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            int x;
            int c;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite dois valores, respeitando a condição de 2º > 1º");
                Console.WriteLine("Digite o primeiro valor");
                n = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Digite o segundo valor");
                x = Convert.ToInt16(Console.ReadLine());
            }
            while (n > x) ;
            Console.WriteLine("Digite o intervalo a ser calculada a sua tabuada? ");
            c = int.Parse(Console.ReadLine());

            for (int f = 1; f <= c; f++)
            {
                Console.WriteLine(n + " x " + f + " = " + f);
            }
        }
    }
}
